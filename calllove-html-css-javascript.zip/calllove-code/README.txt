Two Months, My Favorite Call — source bundle

Files:
- index.html: page content and structure
- styles.css: layout, colors, responsive design, and animation
- script.js: tap-to-open note and share/copy-link behavior
- brand-heart.svg: small heart favicon
- images/: the three supplied call selfies used by the page

To preview locally, keep the files and images/ folder together and open index.html in a modern browser. The hosted page uses its own private project-storage image paths; these standalone copies use relative image paths instead.
